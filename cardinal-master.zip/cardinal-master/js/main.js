// When the DOM is ready,
$(function() {
	// Do stuff;
});
